<!DOCTYPE html>

<head>
    <title>Zoom WebSDK CDN</title>
    <meta charset="utf-8" />
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
</head>

<body>
    <?php
    $course_details = $this->crud_model->get_course_by_id($param2)->row_array();
    $live_class_details = $this->db->where('course_id', $param2)->get('live_class')->row_array();

    $user_id = $this->session->userdata('user_id');
    $user_details = $this->user_model->get_all_user($user_id)->row_array();
    $credentials = $this->db->where('user_id', $user_id)->get('zoom_live_class_settings');

    if ($this->crud_model->is_course_instructor($course_details['id'], $user_id) || $this->session->userdata('admin_login')) {
        $is_host = 1;
    } elseif (enroll_status($course_details['id']) == 'valid') {
        $is_host = 0;
    } else {
        $this->session->flashdata('error_message', get_phrase('You do not have access to this course'));
        redirect($_SERVER['HTTP_REFERER'], 'refresh');
    }

    ?>

    <script src="https://source.zoom.us/3.0.0/lib/vendor/react.min.js"></script>
    <script src="https://source.zoom.us/3.0.0/lib/vendor/react-dom.min.js"></script>
    <script src="https://source.zoom.us/3.0.0/lib/vendor/redux.min.js"></script>
    <script src="https://source.zoom.us/3.0.0/lib/vendor/redux-thunk.min.js"></script>
    <script src="https://source.zoom.us/3.0.0/lib/vendor/lodash.min.js"></script>
    <script src="https://source.zoom.us/zoom-meeting-3.0.0.min.js"></script>

    <script src="<?php echo site_url('assets/lessons/zoom-web-sdk-cdn/js/tool.js'); ?>"></script>
    <script src="<?php echo site_url('assets/lessons/zoom-web-sdk-cdn/js/vconsole.min.js'); ?>"></script>
    <script>
        var mn = "<?php echo $live_class_details['zoom_meeting_id']; ?>";
        var user_name = "<?php echo $user_details['first_name'].' '.$user_details['last_name']; ?>";
        var pwd = "<?php echo $live_class_details['zoom_meeting_password']; ?>";
        var role = <?php echo $is_host; ?>;
        var email = "<?php echo $user_details['email']; ?>";
        var lang = "en-US";
        var china = 0;

        var testTool = window.testTool;
        var meetingConfig = testTool.getMeetingConfig();
        console.log(meetingConfig.name)

        var signature = ZoomMtg.generateSDKSignature({
            meetingNumber: "<?php echo $live_class_details['zoom_meeting_id']; ?>",
            sdkKey: "<?php echo $credentials->row('client_id'); ?>",
            sdkSecret: "<?php echo $credentials->row('client_secret'); ?>",
            role: "<?php echo $is_host; ?>",
            success: function(res) {
                meetingConfig.signature = res;
                meetingConfig.sdkKey = "<?php echo $credentials->row('client_id'); ?>";
                var joinUrl = "<?php echo site_url('addons/liveclass/join/' . $param2 . '?course_id=' . $param2); ?>?" + testTool.serialize(meetingConfig);
                window.location.replace(joinUrl);
            },
        });
    </script>
</body>

</html>