<div class="row">
	<div class="col-md-7" id="noticeboard_form">
		<?php include "noticeboard_form.php"; ?>
	</div>
	<div class="col-md-5">
		<div class="w-100 p-0 m-0 overfloy-y-auto max-height-475 min-height-125" id="notice_list"></div>
	</div>
</div>

<?php include 'noticeboard_scripts.php'; ?>