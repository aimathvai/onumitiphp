<div class="row" id="assignment_front_view">
    <div class="col-md-7" id="assignment_form">
        <?php include "assignment_form.php"; ?>
    </div>
    <div class="col-md-5">
        <div class="w-100 p-0 pb-5 m-0 overflow-hidden overfloy-y-auto max-height-550 min-height-125" id="assignment_list"></div>
    </div>
</div>

<div class="row">
    <div class="w-100" id="submitted_list"></div>
</div>

<?php include 'assignment_scripts.php'; ?>